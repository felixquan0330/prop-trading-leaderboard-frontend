import {util} from './utils.js';
import {setupFormTracking} from './forms.js';
import {sendRequest} from './api.js';

export function initTracker(config) {
    // State
    let state = {
        timeOnPage: 0,
        startTime: Date.now(),
        isVisible: true,
        visitId: util.generateId(),
        forms: config.forms,
        companyId: config.companyId,
        urlParams: util.getUrlParams(),
    };

    // FingerprintJS
    import('https://openfpcdn.io/fingerprintjs/v4')
        .then(FingerprintJS => FingerprintJS.load())
        .then(fp => fp.get())
        .then(result => {
            state.fingerprint = result.visitorId;
            util.log('FingerprintJS Visitor ID:', state.fingerprint);
            startTracking();
        })
        .catch(error => {
            util.log('FingerprintJS error:', error);
            startTracking();
        });

    function startTracking() {
        state.visitorId = getOrCreateVisitorId();
        state.sessionId = getOrCreateSessionId();
        state.trafficSource = detectTrafficSource();

        startTimeTracking();
        setupVisibilityHandling();
        trackPageVisit();
        trackScriptLoad();
        setupFormTracking(state.forms, config, state);
        setupUnloadHandling();
        util.log('Tracker initialized');

        const consent = getConsent();
        // Voorkeuren
        if (consent.preferences) {
            // Code voor voorkeuren, bijvoorbeeld: taal opslaan, dark mode, etc.
        }

        // Statistieken
        if (consent.statistics) {
            // Alleen statistieken-tracking uitvoeren als toestemming is gegeven
        }

        // Marketing
        if (consent.marketing) {
            // Alleen marketing-tracking uitvoeren als toestemming is gegeven
        }
    }

    function getConsent() {
        let consent = {
            necessary: true,
            preferences: false,
            statistics: false,
            marketing: false
        };

        // Cookiebot
        const cookiebot = util.getCookie('CookieConsent');
        if (cookiebot) {
            try {
                const parsed = JSON.parse(cookiebot);
                if (typeof parsed === 'object') {
                    return {
                        necessary: true,
                        preferences: !!parsed.preferences,
                        statistics: !!parsed.statistics,
                        marketing: !!parsed.marketing
                    };
                }
            } catch (e) {
                if (cookiebot.includes('preferences:checked')) consent.preferences = true;
                if (cookiebot.includes('statistics:checked')) consent.statistics = true;
                if (cookiebot.includes('marketing:checked')) consent.marketing = true;
                return consent;
            }
        }

        // Complianz
        if (util.getCookie('cmplz_preferences') === '1') consent.preferences = true;
        if (util.getCookie('cmplz_statistics') === '1') consent.statistics = true;
        if (util.getCookie('cmplz_marketing') === '1') consent.marketing = true;

        // CookieYes
        const cookieyes = util.getCookie('cookieyes-consent');
        if (cookieyes) {
            try {
                const parsed = JSON.parse(cookieyes);
                if (typeof parsed === 'object') {
                    consent.preferences = !!parsed.functional;
                    consent.statistics = !!parsed.analytics;
                    consent.marketing = !!parsed.advertisement;
                    return consent;
                }
            } catch (e) {
            }
        }

        // Borlabs Cookie
        const borlabs = util.getCookie('borlabs-cookie');
        if (borlabs) {
            try {
                const parsed = JSON.parse(borlabs);
                if (typeof parsed === 'object' && parsed.consents) {
                    consent.preferences = !!parsed.consents.preferences;
                    consent.statistics = !!parsed.consents.statistics;
                    consent.marketing = !!parsed.consents.marketing;
                    return consent;
                }
            } catch (e) {
            }
        }

        return consent;
    }

    function getOrCreateVisitorId() {
        let visitorId = util.getCookie('visitor_id') ||
            (window.localStorage && window.localStorage.getItem('visitor_id'));
        if (!visitorId) {
            visitorId = util.generateId();
            if (!util.setCookie('visitor_id', visitorId)) {
                try {
                    if (window.localStorage) {
                        window.localStorage.setItem('visitor_id', visitorId);
                    }
                } catch (e) {
                    util.log('LocalStorage error', e);
                }
            }
        }
        return visitorId;
    }

    function getOrCreateSessionId() {
        let sessionId;
        try {
            sessionId = window.sessionStorage && window.sessionStorage.getItem('session_id');
            if (!sessionId) {
                sessionId = util.generateId();
                window.sessionStorage && window.sessionStorage.setItem('session_id', sessionId);
            }
        } catch (e) {
            sessionId = 'fallback_' + util.generateId();
        }
        return sessionId;
    }

    function detectTrafficSource() {
        const referrer = document.referrer ? new URL(document.referrer) : null;
        const urlParams = state.urlParams;
        if (urlParams.get('utm_source')) {
            return urlParams.get('utm_source');
        }
        if (!referrer) {
            return 'direct';
        }
        const hostname = referrer.hostname.replace('www.', '');
        const currentHostname = window.location.hostname.replace('www.', '');
        const searchEnginePatterns = [
            /google\./i, /bing\./i, /yahoo\./i, /duckduckgo\./i,
            /yandex\./i, /baidu\./i, /ecosia\./i, /aol\./i, /ask\./i
        ];
        const socialMediaPatterns = [
            /facebook\./i, /twitter\./i, /x\.com/i, /linkedin\./i,
            /instagram\./i, /t\.co/i, /reddit\./i, /pinterest\./i,
            /snapchat\./i, /tiktok\./i
        ];
        for (let pattern of searchEnginePatterns) {
            if (pattern.test(hostname)) {
                return 'organic';
            }
        }
        for (let pattern of socialMediaPatterns) {
            if (pattern.test(hostname)) {
                return 'social';
            }
        }
        if (hostname !== currentHostname) {
            return 'referral';
        }
        return 'internal';
    }

    function startTimeTracking() {
        setInterval(() => {
            if (state.isVisible) {
                const now = Date.now();
                const secondsElapsed = Math.floor((now - state.startTime) / 1000);
                state.timeOnPage += secondsElapsed;
                state.startTime = now;
            }
        }, config.updateInterval * 1000 || 5000);
    }

    function setupVisibilityHandling() {
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') {
                state.isVisible = false;
                sendUpdateVisit();
            } else {
                state.isVisible = true;
                state.startTime = Date.now();
            }
        });
        setInterval(() => {
            if (state.isVisible) {
                sendUpdateVisit();
            }
        }, 5000);
    }

    function setupUnloadHandling() {
        window.addEventListener('beforeunload', () => {
            sendUpdateVisit(true);
        });
        window.addEventListener('pagehide', () => {
            sendUpdateVisit(true);
        });
    }

    function trackPageVisit() {
        const url = `${config.apiUrl}/track-visit`;
        const data = {
            visit_id: state.visitId,
            website_id: config.websiteId,
            company_id: config.companyId,
            visitor_id: state.visitorId,
            session_id: state.sessionId,
            fingerprint: state.fingerprint,
            url: window.location.href,
            referrer: document.referrer,
            traffic_source: state.trafficSource,
            gclid: state.urlParams.get('gclid'),
            time_on_page: state.timeOnPage,
            utm_source: state.urlParams.get('utm_source') || '',
            utm_medium: state.urlParams.get('utm_medium') || '',
            utm_campaign: state.urlParams.get('utm_campaign') || '',
            utm_term: state.urlParams.get('utm_term') || '',
            utm_content: state.urlParams.get('utm_content') || '',
            device_type: getDeviceType(),
            browser: getBrowserInfo(),
            os: getOSInfo(),
            language: navigator.language || navigator.userLanguage || '',
            page_title: document.title
        };
        sendRequest(url, data);
    }

    function sendUpdateVisit(isSync = false) {
        const url = `${config.apiUrl}/update-visit`;
        const data = {
            visit_id: state.visitId,
            company_id: config.companyId,
            time_on_page: state.timeOnPage,
        };
        sendRequest(url, data, isSync);
    }

    function trackScriptLoad() {
        const url = `${config.apiUrl}/track-script-load`;
        sendRequest(url, {
            website_id: config.websiteId,
            company_id: config.companyId,
        });
    }

    function getDeviceType() {
        const ua = navigator.userAgent;
        if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
            return 'tablet';
        }
        if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
            return 'mobile';
        }
        return 'desktop';
    }

    function getBrowserInfo() {
        const ua = navigator.userAgent;
        let browser = 'unknown';
        if (ua.indexOf('Chrome') > -1) browser = 'Chrome';
        else if (ua.indexOf('Safari') > -1) browser = 'Safari';
        else if (ua.indexOf('Firefox') > -1) browser = 'Firefox';
        else if (ua.indexOf('MSIE') > -1 || ua.indexOf('Trident/') > -1) browser = 'IE';
        else if (ua.indexOf('Edge') > -1) browser = 'Edge';
        return browser;
    }

    function getOSInfo() {
        const ua = navigator.userAgent;
        let os = 'unknown';
        if (ua.indexOf('Windows') > -1) os = 'Windows';
        else if (ua.indexOf('Mac') > -1) os = 'MacOS';
        else if (ua.indexOf('Linux') > -1) os = 'Linux';
        else if (ua.indexOf('Android') > -1) os = 'Android';
        else if (ua.indexOf('iOS') > -1 || ua.indexOf('iPhone') > -1 || ua.indexOf('iPad') > -1) os = 'iOS';
        return os;
    }
}
