export function getConfig() {
    return window.TrackerConfig || {};
}
